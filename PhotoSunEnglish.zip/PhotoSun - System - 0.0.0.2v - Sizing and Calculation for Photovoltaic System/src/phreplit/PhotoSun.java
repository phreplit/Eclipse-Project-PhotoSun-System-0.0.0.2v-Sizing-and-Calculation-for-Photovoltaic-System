
//Author: PHNO - Tecnólogo | Pós-Graduado
//Release Date: 31/10/2024
//Version: 0.0.0.2v
//Replit: @PHNO, @PHREPLIT
//E-mail: phreplit@gmail.com

//Software: PhotoSun - System - 0.0.0.2v - Sizing and Calculation for Photovoltaic System, with Swing library and compilation in a desktop environment.

package phreplit;

	import java.awt.EventQueue;

	import javax.swing.JFrame;
	import java.awt.CardLayout;
	import java.awt.GridBagLayout;
	import javax.swing.JPanel;
	import javax.swing.JTabbedPane;
	import java.awt.Window.Type;
	import javax.swing.border.BevelBorder;
	import java.awt.SystemColor;
	import javax.swing.border.TitledBorder;
	import javax.swing.border.EtchedBorder;
	import java.awt.Color;
	import java.awt.Toolkit;
	import java.awt.Label;
	import java.awt.Panel;
	import javax.swing.JTextField;
	import javax.swing.JButton;
	import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

	@SuppressWarnings("unused")
	public class PhotoSun {

		private JFrame frmPhotoSun;
		private JTextField textField;
		private JTextField textField_1;
		private JTextField textField_3;
		private JTextField textField_4;
		private JTextField textField_6;
		private JTextField textField_7;
		private JTextField textField_8;
		private JTextField textField_9;
		private JTextField textField_10;
		private JTextField textField_11;
		private JTextField textField_12;
		private JTextField textField_13;
		private JTextField textField_14;
		private JTextField textField_15;
		private JTextField textField_16;
		private JTextField textField_17;
		private JTextField textField_18;
		private JTextField textField_19;
		private JTextField textField_20;
		private JTextField textField_21;
		private JTextField textField_22;
		private JTextField textField_24;

		/**
		 * Launch the application.
		 */
		public static void main(String[] args) {
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						PhotoSun window = new PhotoSun();
						window.frmPhotoSun.setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
		}

		/**
		 * Create the application.
		 */
		public PhotoSun() {
			initialize();
		}

		/**
		 * Initialize the contents of the frame.
		 */
		private void initialize() {
			frmPhotoSun = new JFrame();
			frmPhotoSun.setIconImage(Toolkit.getDefaultToolkit().getImage(PhotoSun.class.getResource("/phreplit/logo_40px.png")));
			frmPhotoSun.getContentPane().setBackground(SystemColor.activeCaption);
			frmPhotoSun.setForeground(SystemColor.activeCaption);
			frmPhotoSun.setTitle("PhotoSun - System - 0.0.0.2v - Sizing and Calculation for Photovoltaic System");
			frmPhotoSun.setResizable(false);
			frmPhotoSun.setBounds(100, 100, 1146, 581);
			frmPhotoSun.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frmPhotoSun.getContentPane().setLayout(null);
			
			JPanel panel = new JPanel();
			panel.setBackground(SystemColor.activeCaption);
			panel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "1. Basic Conversion volts [AC] to watts [DC]", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
			panel.setBounds(10, 10, 270, 282);
			frmPhotoSun.getContentPane().add(panel);
			panel.setLayout(null);
			
			textField = new JTextField();
			textField.setBounds(10, 56, 181, 19);
			panel.add(textField);
			textField.setColumns(10);
			
			textField_1 = new JTextField();
			textField_1.setBounds(10, 105, 181, 19);
			panel.add(textField_1);
			textField_1.setColumns(10);
			
			JButton btnNewButton = new JButton("Convert");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int var1 = 10;
					int mult = Integer.parseInt(textField.getText())*(var1);	
					textField_1.setText(String.valueOf(mult));
				}
			});
			btnNewButton.setBounds(10, 134, 86, 21);
			panel.add(btnNewButton);
			
			JButton btnNewButton_1 = new JButton("Reset");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					textField.setText("");
					textField_1.setText("");

				}
			});
			btnNewButton_1.setBounds(106, 134, 85, 21);
			panel.add(btnNewButton_1);
			
			JLabel lblNewLabel = new JLabel("Enter how many volts you want to convert to watts.:");
			lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 8));
			lblNewLabel.setBounds(10, 33, 250, 13);
			panel.add(lblNewLabel);
			
			JLabel lblNewLabel_1 = new JLabel("The volts entered equal (n) watts.:");
			lblNewLabel_1.setBounds(10, 82, 250, 13);
			panel.add(lblNewLabel_1);
			
			JPanel panel_4 = new JPanel();
			panel_4.setBackground(SystemColor.activeCaption);
			panel_4.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "5. Calculate Monthly Solar Power Generation", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
			panel_4.setBounds(10, 302, 270, 232);
			frmPhotoSun.getContentPane().add(panel_4);
			panel_4.setLayout(null);
			
			JLabel lblNewLabel_12 = new JLabel("Enter the power of the modules in watts.:");
			lblNewLabel_12.setBounds(10, 22, 250, 13);
			panel_4.add(lblNewLabel_12);
			
			JLabel lblNewLabel_15 = new JLabel("Enter the number of hours per day.:");
			lblNewLabel_15.setBounds(10, 60, 250, 13);
			panel_4.add(lblNewLabel_15);
			
			JLabel lblNewLabel_16 = new JLabel("Enter the number of days per month.:");
			lblNewLabel_16.setBounds(10, 96, 250, 13);
			panel_4.add(lblNewLabel_16);
			
			JLabel lblNewLabel_17 = new JLabel("Result - Generation ");
			lblNewLabel_17.setBounds(10, 135, 250, 13);
			panel_4.add(lblNewLabel_17);
			
			textField_12 = new JTextField();
			textField_12.setBounds(10, 40, 180, 19);
			panel_4.add(textField_12);
			textField_12.setColumns(10);
			
			textField_13 = new JTextField();
			textField_13.setBounds(10, 74, 180, 19);
			panel_4.add(textField_13);
			textField_13.setColumns(10);
			
			textField_14 = new JTextField();
			textField_14.setBounds(10, 114, 180, 19);
			panel_4.add(textField_14);
			textField_14.setColumns(10);
			
			textField_15 = new JTextField();
			textField_15.setBounds(10, 170, 180, 19);
			panel_4.add(textField_15);
			textField_15.setColumns(10);
			
			JButton btnNewButton_8 = new JButton("Calculate");
			btnNewButton_8.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int var4 = 1000;
					int mult4 = Integer.parseInt(textField_12.getText())*Integer.parseInt(textField_13.getText())*Integer.parseInt(textField_14.getText());
		            int result2 = mult4 / var4;
					textField_15.setText(String.valueOf(result2)); 
				}
			});
			btnNewButton_8.setBounds(10, 201, 94, 21);
			panel_4.add(btnNewButton_8);
			
			JButton btnNewButton_9 = new JButton("Reset");
			btnNewButton_9.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					textField_12.setText("");
					textField_13.setText("");
					textField_14.setText("");
					textField_15.setText("");
					
				}
			});
			btnNewButton_9.setBounds(105, 201, 85, 21);
			panel_4.add(btnNewButton_9);
			
			JLabel lblNewLabel_26 = new JLabel("is (n) kwh/month [east/west.].:");
			lblNewLabel_26.setBounds(10, 148, 250, 13);
			panel_4.add(lblNewLabel_26);
			
			JPanel panel_5 = new JPanel();
			panel_5.setBackground(SystemColor.activeCaption);
			panel_5.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "6. Calc. Annual Solar Energy Generation", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
			panel_5.setBounds(290, 302, 264, 232);
			frmPhotoSun.getContentPane().add(panel_5);
			panel_5.setLayout(null);
			
			JLabel lblNewLabel_13 = new JLabel("Enter the power of the modules in watts.:");
			lblNewLabel_13.setBounds(10, 22, 244, 13);
			panel_5.add(lblNewLabel_13);
			
			JLabel lblNewLabel_18 = new JLabel("Enter the number of hours per day.:");
			lblNewLabel_18.setBounds(10, 60, 244, 13);
			panel_5.add(lblNewLabel_18);
			
			JLabel lblNewLabel_19 = new JLabel("Enter the number of days per year.:");
			lblNewLabel_19.setBounds(10, 96, 244, 13);
			panel_5.add(lblNewLabel_19);
			
			JLabel lblNewLabel_20 = new JLabel("Result - Generation ");
			lblNewLabel_20.setBounds(10, 135, 244, 13);
			panel_5.add(lblNewLabel_20);
			
			textField_16 = new JTextField();
			textField_16.setBounds(10, 40, 180, 19);
			panel_5.add(textField_16);
			textField_16.setColumns(10);
			
			textField_17 = new JTextField();
			textField_17.setBounds(10, 74, 180, 19);
			panel_5.add(textField_17);
			textField_17.setColumns(10);
			
			textField_18 = new JTextField();
			textField_18.setBounds(10, 114, 180, 19);
			panel_5.add(textField_18);
			textField_18.setColumns(10);
			
			textField_19 = new JTextField();
			textField_19.setBounds(10, 170, 180, 19);
			panel_5.add(textField_19);
			textField_19.setColumns(10);
			
			JButton btnNewButton_10 = new JButton("Calculate");
			btnNewButton_10.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int var5 = 1000;
					int mult5 = Integer.parseInt(textField_16.getText())*Integer.parseInt(textField_17.getText())*Integer.parseInt(textField_18.getText());
		            int result3 = mult5 / var5;
					textField_19.setText(String.valueOf(result3)); 
				}
			});
			btnNewButton_10.setBounds(10, 201, 94, 21);
			panel_5.add(btnNewButton_10);
			
			JButton btnNewButton_11 = new JButton("Reset");
			btnNewButton_11.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					textField_16.setText("");
					textField_17.setText("");
					textField_18.setText("");
					textField_19.setText("");
					
				}
			});
			btnNewButton_11.setBounds(105, 201, 85, 21);
			panel_5.add(btnNewButton_11);
			
			JLabel lblNewLabel_25 = new JLabel("is (n) kwh/year [east/west.].:");
			lblNewLabel_25.setBounds(10, 150, 244, 13);
			panel_5.add(lblNewLabel_25);
			
			JPanel panel_6 = new JPanel();
			panel_6.setBackground(SystemColor.activeCaption);
			panel_6.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "7. Calc. and Size the Number of Modules", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
			panel_6.setBounds(570, 302, 265, 232);
			frmPhotoSun.getContentPane().add(panel_6);
			panel_6.setLayout(null);
			
			JLabel lblNewLabel_14 = new JLabel("Enter the calculated system power (Pfv[BR]) in watts.:");
			lblNewLabel_14.setFont(new Font("Tahoma", Font.BOLD, 8));
			lblNewLabel_14.setBounds(10, 22, 245, 13);
			panel_6.add(lblNewLabel_14);
			
			JLabel lblNewLabel_21 = new JLabel("Enter the module's rated power in watts.:");
			lblNewLabel_21.setBounds(10, 66, 245, 13);
			panel_6.add(lblNewLabel_21);
			
			JLabel lblNewLabel_22 = new JLabel("Result - The maximum number of ");
			lblNewLabel_22.setBounds(10, 111, 245, 13);
			panel_6.add(lblNewLabel_22);
			
			JLabel lblNewLabel_23 = new JLabel("modules sized is (n) photovoltaic panels.:");
			lblNewLabel_23.setBounds(10, 134, 245, 13);
			panel_6.add(lblNewLabel_23);
			
			textField_20 = new JTextField();
			textField_20.setBounds(10, 40, 180, 19);
			panel_6.add(textField_20);
			textField_20.setColumns(10);
			
			textField_21 = new JTextField();
			textField_21.setBounds(10, 82, 180, 19);
			panel_6.add(textField_21);
			textField_21.setColumns(10);
			
			textField_22 = new JTextField();
			textField_22.setBounds(10, 153, 180, 19);
			panel_6.add(textField_22);
			textField_22.setColumns(10);
			
			JButton btnNewButton_12 = new JButton("Calculate");
			btnNewButton_12.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int div2 = Integer.parseInt(textField_20.getText())/Integer.parseInt(textField_21.getText());
					textField_22.setText(String.valueOf(div2)); 
				}
			});
			btnNewButton_12.setBounds(10, 182, 94, 21);
			panel_6.add(btnNewButton_12);
			
			JButton btnNewButton_13 = new JButton("Reset");
			btnNewButton_13.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					textField_20.setText("");
					textField_21.setText("");
					textField_22.setText("");

				}
			});
			btnNewButton_13.setBounds(105, 182, 85, 21);
			panel_6.add(btnNewButton_13);
			
			JPanel panel_7 = new JPanel();
			panel_7.setBackground(SystemColor.activeCaption);
			panel_7.setBorder(new TitledBorder(null, "Setup", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			panel_7.setBounds(850, 302, 270, 232);
			frmPhotoSun.getContentPane().add(panel_7);
			panel_7.setLayout(null);
			
			JButton btnNewButton_14 = new JButton("Info");
			btnNewButton_14.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(
							null,"Info\n"
							+ "\nBasic Conversion - To convert volts to watts we multiply the volts by 10."
			                + "\nBasic Conversion - To convert watts to volts we divide the watts by 10."
			                + "\nTo calculate the power of the modules, we multiply the nominal power of the module by the number of modules."
			                + "\nTo calculate weekly generation we use the calculation (power of modules) x (hours per day) x (days per week)."
			                + "\nTo calculate the monthly generation we use the calculation (power of the modules) x (hours per day) x (days per month)."
			                + "\nTo calculate the annual generation we use the calculation (power of the modules) x (hours per day) x (days per year)."
			                + "\nTo calculate and size the number of modules that make a solar panel, we use the following calculation:"
			                + "\nCalculated system power (Pfv[BR]) in watts divided by the nominal module power in watts = the Number of Modules."
			                + "\nTo convert 1kwh to 1wh just do the calculation e.g.: 73kwh to wh will be 73000wh. So it will be 1kwh = 1000wh.");

				}
			});
			btnNewButton_14.setBounds(95, 67, 85, 21);
			panel_7.add(btnNewButton_14);
			
			JButton btnNewButton_15 = new JButton("About");
			btnNewButton_15.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(null,"Software:  PhotoSun - Sizing and Calculation for Photovoltaic System\n"+"\nAuthor: PHNO"+"\nRelease Date: 31/10/2024"+"\nVersion: 0.0.0.2v"+"\nReplit: @PHNO, @PHREPLIT"+"\nE-mail: phreplit@gmail.com");
				}
			});
			btnNewButton_15.setBounds(95, 98, 85, 21);
			panel_7.add(btnNewButton_15);
			
			JButton btnNewButton_16 = new JButton("Clear Data");
			btnNewButton_16.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					textField.setText("");
					textField_1.setText("");
					textField_3.setText("");
					textField_4.setText("");
					textField_6.setText("");
					textField_7.setText("");
					textField_8.setText("");
					textField_9.setText("");
					textField_10.setText("");
					textField_11.setText("");
					textField_12.setText("");
					textField_13.setText("");
					textField_14.setText("");
					textField_15.setText("");
					textField_16.setText("");
					textField_17.setText("");
					textField_18.setText("");
					textField_19.setText("");
					textField_20.setText("");
					textField_21.setText("");
					textField_22.setText("");
					textField_24.setText("");
				}
			});
			btnNewButton_16.setBounds(81, 129, 112, 21);
			panel_7.add(btnNewButton_16);
			
			JPanel panel_1 = new JPanel();
			panel_1.setBackground(SystemColor.activeCaption);
			panel_1.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "2. Basic Conversion watts [DC] to volts [AC]", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
			panel_1.setBounds(290, 10, 264, 282);
			frmPhotoSun.getContentPane().add(panel_1);
			panel_1.setLayout(null);
			
			JLabel lblNewLabel_3 = new JLabel("Enter how many watts you want to convert to volts.:");
			lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 8));
			lblNewLabel_3.setBounds(10, 34, 244, 13);
			panel_1.add(lblNewLabel_3);
			
			JLabel lblNewLabel_4 = new JLabel("The watts entered equal (n) volts.:");
			lblNewLabel_4.setBounds(10, 84, 244, 13);
			panel_1.add(lblNewLabel_4);
			
			textField_3 = new JTextField();
			textField_3.setBounds(10, 55, 180, 19);
			panel_1.add(textField_3);
			textField_3.setColumns(10);
			
			textField_4 = new JTextField();
			textField_4.setBounds(10, 105, 180, 19);
			panel_1.add(textField_4);
			textField_4.setColumns(10);
			
			JButton btnNewButton_2 = new JButton("Convert");
			btnNewButton_2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int var2 = 10;
					int div = Integer.parseInt(textField_3.getText())/(var2);	
					textField_4.setText(String.valueOf(div));
				}
			});
			btnNewButton_2.setBounds(10, 134, 85, 21);
			panel_1.add(btnNewButton_2);
			
			JButton btnNewButton_3 = new JButton("Reset");
			btnNewButton_3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					textField_3.setText("");
					textField_4.setText("");
					
				}
			});
			btnNewButton_3.setBounds(105, 134, 85, 21);
			panel_1.add(btnNewButton_3);
			
			JPanel panel_2 = new JPanel();
			panel_2.setBackground(SystemColor.activeCaption);
			panel_2.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "3. Calculate the Power of the Modules", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
			panel_2.setBounds(571, 10, 264, 280);
			frmPhotoSun.getContentPane().add(panel_2);
			panel_2.setLayout(null);
			
			JLabel lblNewLabel_6 = new JLabel("Enter the nominal power of the modules in watts.:");
			lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 8));
			lblNewLabel_6.setBounds(10, 33, 244, 13);
			panel_2.add(lblNewLabel_6);
			
			textField_6 = new JTextField();
			textField_6.setBounds(10, 56, 180, 19);
			panel_2.add(textField_6);
			textField_6.setColumns(10);
			
			textField_7 = new JTextField();
			textField_7.setBounds(10, 107, 180, 19);
			panel_2.add(textField_7);
			textField_7.setColumns(10);
			
			textField_8 = new JTextField();
			textField_8.setBounds(10, 160, 180, 19);
			panel_2.add(textField_8);
			textField_8.setColumns(10);
			
			JLabel lblNewLabel_8 = new JLabel("Enter the number of modules.:");
			lblNewLabel_8.setBounds(10, 85, 244, 13);
			panel_2.add(lblNewLabel_8);
			
			JLabel lblNewLabel_10 = new JLabel("The power of the modules is (n) watts.:");
			lblNewLabel_10.setBounds(10, 137, 244, 13);
			panel_2.add(lblNewLabel_10);
			
			JButton btnNewButton_4 = new JButton("Calculate");
			btnNewButton_4.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int mult2 = Integer.parseInt(textField_6.getText())*Integer.parseInt(textField_7.getText());
					textField_8.setText(String.valueOf(mult2)); 
				}
			});
			btnNewButton_4.setBounds(10, 189, 94, 21);
			panel_2.add(btnNewButton_4);
			
			JButton btnNewButton_5 = new JButton("Reset");
			btnNewButton_5.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					textField_6.setText("");
					textField_7.setText("");
					textField_8.setText("");
					
				}
			});
			btnNewButton_5.setBounds(105, 189, 85, 21);
			panel_2.add(btnNewButton_5);
			
			JPanel panel_3 = new JPanel();
			panel_3.setBackground(SystemColor.activeCaption);
			panel_3.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "4. Calculate Weekly Solar Power Generation", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
			panel_3.setBounds(850, 10, 270, 282);
			frmPhotoSun.getContentPane().add(panel_3);
			panel_3.setLayout(null);
			
			textField_9 = new JTextField();
			textField_9.setBounds(10, 56, 180, 19);
			panel_3.add(textField_9);
			textField_9.setColumns(10);
			
			textField_10 = new JTextField();
			textField_10.setBounds(10, 93, 180, 19);
			panel_3.add(textField_10);
			textField_10.setColumns(10);
			
			textField_11 = new JTextField();
			textField_11.setBounds(10, 139, 180, 19);
			panel_3.add(textField_11);
			textField_11.setColumns(10);
			
			JLabel lblNewLabel_7 = new JLabel("Enter the power of the modules in watts.:");
			lblNewLabel_7.setBounds(10, 34, 250, 13);
			panel_3.add(lblNewLabel_7);
			
			JLabel lblNewLabel_9 = new JLabel("Enter the number of hours per day.:");
			lblNewLabel_9.setBounds(10, 80, 250, 13);
			panel_3.add(lblNewLabel_9);
			
			JLabel lblNewLabel_11 = new JLabel("Enter the number of days per week.:");
			lblNewLabel_11.setBounds(10, 122, 250, 13);
			panel_3.add(lblNewLabel_11);
			
			JButton btnNewButton_6 = new JButton("Calculate");
			btnNewButton_6.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int var3 = 1000;
					int mult3 = Integer.parseInt(textField_9.getText())*Integer.parseInt(textField_10.getText())*Integer.parseInt(textField_11.getText());
		            int result = mult3 / var3;
					textField_24.setText(String.valueOf(result)); 
				}
			});
			btnNewButton_6.setBounds(10, 230, 94, 21);
			panel_3.add(btnNewButton_6);
			
			JButton btnNewButton_7 = new JButton("Reset");
			btnNewButton_7.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					textField_9.setText("");
					textField_10.setText("");
					textField_11.setText("");
					textField_24.setText("");
				}
			});
			btnNewButton_7.setBounds(105, 230, 85, 21);
			panel_3.add(btnNewButton_7);
			
			JLabel lblNewLabel_24 = new JLabel("Result - Generation ");
			lblNewLabel_24.setBounds(10, 161, 250, 13);
			panel_3.add(lblNewLabel_24);
			
			textField_24 = new JTextField();
			textField_24.setBounds(10, 201, 180, 19);
			panel_3.add(textField_24);
			textField_24.setColumns(10);
			
			JLabel lblNewLabel_27 = new JLabel("is (n) kwh/week [east/west.].:");
			lblNewLabel_27.setBounds(10, 178, 250, 13);
			panel_3.add(lblNewLabel_27);
		}
	}

